<?php

$nrp ="701240155";
$nama ="ella elvira";
$umur = 19;
$nilai =85.85;

echo "Nrp :". $nrp ."</br>";
echo "Nama: $nama</br>";
print "Umur : ".$umur; print "</br>";
//menampilkan bilangan real dengan format 3 digit dibelakang koma
printf ("Nilai :%.3f</br>",$nilai);

?>

<?php

$x = 21;
$y = 3;

echo "x = $x</br>";
echo "y = $y</br>";

$hasilBagi = $x /$y;
echo "Hasil bagi dari x / y = $hasilBagi </br>";

$hasilKali =$x * $y;
echo "Hasil kali dari x * y= $hasilKali </br>";

?>
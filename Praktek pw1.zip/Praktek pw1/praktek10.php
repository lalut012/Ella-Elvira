<?php

function varstatic(){
    static $x = 1;//mendeklarasikan variabel statis
    echo $x;
    $x++;
    echo "</br>";
}

varStatic(); //memanggil function varstatic
varStatic();
varStatic();

?>
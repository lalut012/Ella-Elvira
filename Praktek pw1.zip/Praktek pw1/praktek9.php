<?php

$GLOBALS['varGlobal'] = 18;

function testVar()
{
    $varLokal = 1; //variabel lokal
    echo "<p> test variabel didalam function.<p>";
    echo "varibel global : ".$GLOBALS['varGlobal'];
    echo "<br>";
    echo "varibel lokal : $varLokal ";
    echo "<br>";
}

testVar();

    echo "<p> test variabel didalam function.<p>";
    echo "Varibel global : $varGlobal ";
    echo "<br>";

    echo "Varibel lokal : $varLokal";
    echo "<br>";
    
?>
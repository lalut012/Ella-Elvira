<?php

define('HALO', 'Hello world!');
define('PI','3.14');

echo HALO;
echo "</br>";
echo PI;

?>
<?php

    echo strlen("Ella Elvira");
    echo "</br>";
    echo date("1, d - M - Y");
    echo "</br>";
    echo htmlspecialchars("<img src='img.jpg'>", ENT_NOQUOTES);

?>
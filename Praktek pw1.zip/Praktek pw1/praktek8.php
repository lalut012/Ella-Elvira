<?php

    function nominal($nominal =10000){
        echo "nominal = $nominal";
    };

    nominal(12500);
    echo "</br>";
    nominal();

?>

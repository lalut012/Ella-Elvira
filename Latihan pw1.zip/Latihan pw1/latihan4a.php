<!DOCTYPE html>
<html>
<head>
    <title>Latihan 4a</title>
    <style>
        /* Opsional: Jika Anda ingin menyesuaikan warna default mark,
           tambahkan CSS berikut. Umumnya, browser akan memberi warna kuning default. */
        mark {
            background-color: yellow; /* Pastikan warnanya kuning */
        }
    </style>
</head>
<body>

<?php

$warna_balon = array("hijau", "kuning", "kelabu", "merah muda");

echo "Balonku ada lima.<br>";
echo "Rupa-rupa warnanya<br>";

echo "<mark>" . $warna_balon[0] . "</mark>, ";
echo "<mark>" . $warna_balon[1] . "</mark>, ";
echo "<mark>" . $warna_balon[2] . "</mark>, ";
echo "<mark>" . $warna_balon[3] . "</mark>, dan <mark>biru</mark><br>";

echo "Meletus balon <mark>" . $warna_balon[0] . "</mark> DOR!!!<br>";
echo "Hatiku sangat kacau..<br>";

?>

</body>
</html>
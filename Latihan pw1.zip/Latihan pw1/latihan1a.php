<?php
    $kata1 = " Topi";
    $kata2 = " Bundar";

    echo $kata1." Saya". $kata2. ",". $kata2. $kata1." Saya.";
?>
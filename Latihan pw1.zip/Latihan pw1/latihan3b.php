<!DOCTYPE html>
<html>
<head>
    <title>Latihan3b.php</title>
</head>
<body>

<h2>Perbedaan Fungsi <code>isset()</code> dan <code>empty()</code></h2>

<?php
$var1 = "Halo";
$var2 = "";
$var3 = null;

// Penjelasan isset()
echo "<h3>Contoh isset():</h3>";
echo "isset(\$var1): " . (isset($var1) ? "TRUE" : "FALSE") . "<br>";
echo "isset(\$var2): " . (isset($var2) ? "TRUE" : "FALSE") . "<br>";
echo "isset(\$var3): " . (isset($var3) ? "TRUE" : "FALSE") . "<br>";
echo "isset(\$var4): " . (isset($var4) ? "TRUE" : "FALSE") . " (variabel belum dibuat)<br>";

// Penjelasan empty()
echo "<h3>Contoh empty():</h3>";
echo "empty(\$var1): " . (empty($var1) ? "TRUE" : "FALSE") . "<br>";
echo "empty(\$var2): " . (empty($var2) ? "TRUE" : "FALSE") . "<br>";
echo "empty(\$var3): " . (empty($var3) ? "TRUE" : "FALSE") . "<br>";
echo "empty(\$var4): " . (empty($var4) ? "TRUE" : "FALSE") . " (variabel belum dibuat)<br>";
?>

<hr>
<h3>Penjelasan Singkat:</h3>
<ul>
    <li><strong>isset()</strong> mengecek apakah suatu variabel <u>sudah dibuat</u> dan <u>tidak null</u>.</li>
    <li><strong>empty()</strong> mengecek apakah variabel <u>kosong</u> ("" atau 0 atau null atau false, dll).</li>
</ul>

</body>
</html>
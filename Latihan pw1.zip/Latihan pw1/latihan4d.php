<?php

$dataNegara = [
    ["Indonesia", "D.K.I. Jakarta", "+62"],
    ["Singapura", "Singapura", "+65"],
    ["Malaysia", "Kuala Lumpur", "+60"],
    ["Brunei", "Bandar Seri Begawan", "+673"],
    ["Thailand", "Bangkok", "+66"],
    ["Laos", "Vientiane", "+856"],
    ["Filipina", "Manila", "+63"],
    ["Myanmar", "Naypyidaw", "+95"]
];

echo "<table border='1'>";
echo "<tr><th>Negara</th><th>Ibukota</th><th>Kode Telepon</th></tr>";

foreach ($dataNegara as $negara) {
    echo "<tr>";
    echo "<td>" . $negara[0] . "</td>"; // Negara
    echo "<td>" . $negara[1] . "</td>"; // Ibukota
    echo "<td>" . $negara[2] . "</td>"; // Kode Telepon
    echo "</tr>";
}

echo "</table>";

?>
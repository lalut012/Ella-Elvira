<?php

echo "<!DOCTYPE html>";
echo "<html lang='id'>";
echo "<head>";
echo "    <meta charset='UTF-8'>";
echo "    <meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "    <title>Deteksi Bilangan Ganjil, Genap, Prima</title>";
echo "    <style>";
echo "        body { font-family: Arial, sans-serif; margin: 20px; background-color: #f4f4f4; }";
echo "        .container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 600px; margin: auto; }";
echo "        h2 { color: #333; border-bottom: 2px solid #eee; padding-bottom: 10px; margin-bottom: 20px; }";
echo "        ul { list-style: none; padding: 0; }";
echo "        li { background-color: #e9e9e9; margin-bottom: 8px; padding: 10px; border-radius: 4px; border-left: 5px solid #007bff; }";
echo "        li.genap { border-left-color: #28a745; }";
echo "        li.ganjil { border-left-color: #ffc107; }";
echo "        li.prima { border-left-color: #dc3545; }";
echo "    </style>";
echo "</head>";
echo "<body>";
echo "    <div class='container'>";

echo "        <h2>Pengulangan untuk mencari kategori bilangan :</h2>";
echo "        <ul>";

// Fungsi untuk mengecek apakah bilangan prima
function isPrime($num) {
    // Bilangan kurang dari atau sama dengan 1 bukan prima
    if ($num <= 1) {
        return false;
    }
    // 2 adalah satu-satunya bilangan prima genap
    if ($num == 2) {
        return true;
    }
    // Jika genap dan bukan 2, pasti bukan prima
    if ($num % 2 == 0) {
        return false;
    }
    // Cek pembagi ganjil dari 3 hingga akar kuadrat dari num
    // Langkah 2 (i+=2) karena kita sudah menyingkirkan bilangan genap
    for ($i = 3; $i * $i <= $num; $i += 2) {
        if ($num % $i == 0) {
            return false; // Ada pembagi lain, bukan prima
        }
    }
    return true; // Tidak ada pembagi lain, itu prima
}

// Loop dari 1 sampai 19
for ($i = 1; $i <= 19; $i++) {
    $category_text = ""; // Variabel untuk menyimpan teks kategori
    $css_class = "";     // Variabel untuk menyimpan kelas CSS

    // Cek ganjil/genap
    if ($i % 2 == 0) {
        $category_text = "genap";
        $css_class = "genap";
    } else {
        $category_text = "ganjil";
        $css_class = "ganjil";
    }

    // Cek prima
    if (isPrime($i)) {
        // Jika bilangan prima (dan bukan 1, karena 1 bukan prima)
        // Kita tambahkan teks "sekaligus bilangan prima" dan kelas 'prima'
        $category_text .= " sekaligus bilangan prima";
        $css_class .= " prima"; // Tambahkan kelas prima
    }

    // Output daftar item dengan kelas CSS yang sesuai
    echo "<li class='" . trim($css_class) . "'>Angka " . $i . " adalah bilangan " . $category_text . "</li>";
}

echo "        </ul>";
echo "    </div>";
echo "</body>";
echo "</html>";
?>
<?php

$asean_awal = ["Indonesia", "Singapura", "Malaysia", "Brunei", "Thailand"];

echo "<h3>Daftar Negara ASEAN awal :</h3>";
echo "<ul>";
foreach ($asean_awal as $negara) {
    echo "<li>$negara</li>";
}
echo "</ul>";

$asean_baru = $asean_awal;
array_push($asean_baru, "Laos", "Filipina", "Myanmar");

echo "<h3>Daftar Negara ASEAN baru :</h3>";
echo "<ul>";
foreach ($asean_baru as $negara) {
    echo "<li>$negara</li>";
}
echo "</ul>";
?>
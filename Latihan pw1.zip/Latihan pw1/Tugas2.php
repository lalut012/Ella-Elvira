<?php
$macam_teknologi = [
["nama" => "smartphone",
"waktu pembuatan" => "1994",
"ciri khas" => "sistem operasi,konektivitas internet,layar sentuh,aplikasi",
"deskripsi" => "telepon seluler canggih yang berfungsi seperti komputer mini dan untuk komunikasi, hiburan, produktivitas, dan navigasi.",
"gambar" => "image/smarphone.jpg"
],
["nama" => "Internet of Things (IoT)",
"waktu pembuatan" => "kevin aston 1999",
"ciri khas" => "konektivitas,Sensor dan Auktor,otomatisasi,pertukaran data",
"deskripsi" => "Konsep di mana objek-objaek fisik sehari-hari terhubung ke internet,memungkinkan untuk mengumpulkan dan bertukar data.",
"gambar" => "image/iot.png"
],
["nama" => " Sistem Pembayaran Digital E-Commerce",
"waktu pembuatan" => "1990-an",
"ciri khas" => "berbasis elektronik,kecepatan",
"deskripsi" => "Memungkinkan transaksi jual beli online dilakukan tanpa menggunakan uang tunai dan cek fisik.",
"gambar" => "image/e-commerce.jpg"
],
["nama" => "Sistem Navigasi GPS",
"waktu pembuatan" => "1973",
"ciri khas" => "berbasis satrelit, akurasi tinggi,tersedia 24/7&bebas cuaca",
"deskripsi" => " Sistem navigasi berbasis satelit yang menyediakan informasi lokasi, kecepatan, dan waktu yang akurat di mana pun.",
"gambar" => "image/gps.jpg"
],
["nama" => "Aplikasi Medis dan Kesehatan",
"waktu pembuatan" => "awal 1990-2000an",
"ciri khas" => "Perangkat lunak yang dirancang untuk membantu individu mengelola kesehatan, mengakses informasi medis,atau terhubung dengan penyedia layanan kesehatan.",
"gambar" => "image/apk medis&kesehatan.jpg"
],
["nama" => "Teknologi Augmented Reality (AR) dan Virtual Reality (VR)",
"waktu pembuatan" => "1960-an - sekarang",
"ciri khas" => "Menggabungkan Dunia Nyata dan Digital,Lingkungan Buatan Sepenuhnya,Responsif terhadap Gerakan Kepala dan Tubuh",
"deskripsi" => "menciptakan pengalaman interaktif dan imersif, baik dalam dunia nyata (AR) maupun dunia maya (VR).",
"gambar" => "image/vr&ar.jpg"
],
["nama" => "Teknologi AI dalam Asisten Virtual",
"waktu pembuatan" => "2001 - sekarang ",
"ciri khas" => "Kemampuan Belajar (Machine Learning),Meniru Kecerdasan Manusia,Otomatisasi Tugas, Natural Language Processing (NLP), Berbasis Suara dan/atau Teks.",
"deskripsi" => "Asisten virtual untuk memahami, memproses, dan merespons perintah manusia dengan cara yang terasa alami dan intuitif.",
"gambar" => "image/AI.jpg"
],
["nama" => "robot",
"waktu pembuatan"=> "sebelum masehi - sekarang",
"ciri khas" => "Bentuk Fisik atau Mekanik,Dapat Diprogram,Kemampuan Sensorik, Aktuator atau Penggerak, Integrasi dengan AI (pada robot cerdas)",
"deskripsi" => "Robot adalah mesin atau perangkat otomatis yang dapat melakukan tugas tertentu secara otomatis, baik secara mandiri maupun dengan kendali manusia.robot sering digunakan untuk tugas-tugas yang repetitif, berbahaya atau membutuhkan presisi tinggi yang sulit atau tidak mungkin dilakukan oleh manusia.",
"gambar" => "image/Robot.jpg"
],
["nama" => "kereta hyperloop",
"waktu pembuatan" => "2012-sekarang",
"ciri khas" => "Hyperloop bisa mengangkut 20-40 penumpang dan dapat melaju dengan kecepatan 1.7000 km/ jam.",
"deskripsi" => "Hyperloop yaitu adalah konsep sistem transportasi berkecepatan tinggi yang revolusioner,digagas oleh Elon Musk.",
"gambar" => "image/hyperloop.jpg"
],
["nama" => "Hoverboard",
"waktu pembuatan" => "2013-sekarang",
"ciri khas" => " Skateboard terbang ini bekerja dengan cara menyeimbangan kondisi pengguna dan menyesuaikan navigasinya.",
"deskripsi" => "Hoverboard adalah perangkat transportasi pribadi beroda dua bertenaga listrik yang populer, yang dikendalikan oleh pergeseran berat tubuh pengguna.",
"gambar" => "image/hoverboard.jpg"
],

]
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        img{
            width: 200px;
        }
        td{
            text-align:center;
        }
    </style>
</head>
<body>
 <table  border="1">
<tr>
<th>no</th>
<th>nama teknologi</th>
<th>waktu pembuatan</th>
<th>ciri khas</th>
<th>deskripsi</th>
<th>gambar</th>
</tr>
    <?php foreach ($macam_teknologi as $index => $data ):?>
    <tr>
    <td><?= $index + 1 ?></td>
    <td><?= $data['nama']; ?></td>
    <td><?= $data['waktu pembuatan']; ?></td>
    <td><?= $data['ciri khas']; ?></td>
    <td><?= $data['deskripsi']; ?></td>
   <td> <img src="<?= $data['gambar']?>" ></td>
   </tr>
   <?php endforeach;?>
   </table>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modul 2 - Latihan 1</title>
    <style>
        .kotak {
            border: 1px solid black;
            width: 30px; /* Sesuaikan lebar sesuai kebutuhan */
            height: 30px; /* Sesuaikan tinggi sesuai kebutuhan */
            display: inline-block;
            text-align: center;
            line-height: 30px;
            margin: 2px;
            box-sizing: border-box; /* Agar padding dan border tidak menambah ukuran */
        }
        .clear {
            clear: both;
        }
    </style>
</head>
<body>
    <?php
    $jumlah_baris = 5; // Variabel untuk menentukan jumlah baris

    for ($i = 1; $i <= $jumlah_baris; $i++) {
        $jumlah_kolom = $i; // Jumlah kolom mengikuti nomor baris

        for ($j = 1; $j <= $jumlah_kolom; $j++) {
            echo '<div class="kotak">' . $j . '</div>';
        }
        echo '<div class="clear"></div>'; // Untuk baris baru
    }
    ?>

</body>
</html>
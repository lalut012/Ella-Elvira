<?php

function faktorial($a) {
    $hasil = 1;
    for ($i = 1; $i <= $a; $i++) {
        $hasil *= $i;
    }
    return $hasil;
}

    $angka = 5;
    $hasil = faktorial($angka);

echo "<div class='output'>Faktorial dari $angka = $hasil</div>";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Latihan3d.php</title>
    <style>
        .output {
            font-size: 24px;
            font-family: Arial, sans-serif;
            border: 2px solid #333;
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
        }
    </style>
    
</head>
</body>
</html>
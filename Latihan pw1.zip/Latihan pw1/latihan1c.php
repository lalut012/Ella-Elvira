<?php
    $a = "A";
    $b = "B";
    $c = "C";

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8"
    <title>latihan 3 modul 1</title>
    <style>
        .kotak {
            width: 60px;
            height: 60px;
            font-size:40px;
            display:flex;
            justify-content: center;
            border:2px solid black;
            margin: 10px;
            boerder-radius:10px;
            text-align:center;
        }

        table {
            border: 2px solid black
        }
    </style>
</head>
<body>
    <table>
        <tr>
            <!-- baris 1 -->
            <td><div class="kotak"><?php echo $a; ?></div> </td>
            <br>
        </tr>

        <tr>
            <!-- baris 2 -->
            <td><div class="kotak"><?php echo $a; ?></div> </td>
            <td><div class="kotak"><?php echo $b; ?></div> </td>
    
            <br>
        </tr>

        <tr>
            <!-- baris 3 -->
             <td><div class="kotak"><?php echo $a; ?></div> </td>
             <td><div class="kotak"><?php echo $b; ?></div> </td>
             <td><div class="kotak"><?php echo $c; ?></div> </td>
        </tr>
    </table>
 </body>
 </html>


<?PHP
    $angka = 10;

    echo"Aku adalah angka". $angka. "<br>";
    echo"Jika aku dikali 8, jumlahku sekarang ". ($angka*8). "<br>";
    echo"Jika aku dibagi 4, jumlahku sekarang ". ($angka/4). "<br>";
    echo"Jika aku dikurang 6, jumlahku sekarang ". ($angka-6). "<br>";
    echo"Jika aku ditambah 2, jumlahku sekarang ". ($angka+2). "<br>";


?>
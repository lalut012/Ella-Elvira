<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modul 2 - Latihan 1</title>
</head>
<body>
    <table border="1" cellpadding="3" cellspacing="0">
        <tr>
            <th>Kolom 1</th>
            <th>Kolom 2</th>
            <th>Kolom 3</th>
            <th>Kolom 4</th>
            <th>Kolom 5</th>
        </tr>
        <?php 
        $jumlahBaris = 15; // Mendefinisikan jumlah baris yang diinginkan
        $jumlahKolom = 5; // Mendefinisikan jumlah kolom yang diinginkan

        // Melakukan perulangan untuk setiap baris
        for ($i = 1; $i <= $jumlahBaris; $i++) {
            echo "<tr>"; // Membuka tag baris tabel
            // Melakukan perulangan untuk setiap kolom dalam baris saat ini
            for ($j = 1; $j <= $jumlahKolom; $j++) {
                echo "<td>Baris " . $i . " Kolom " . $j . "</td>"; // Menampilkan teks "Baris X Kolom Y"
            }
            echo "</tr>"; // Menutup tag baris tabel
        }
        ?>
    </table>
</body>
</html>